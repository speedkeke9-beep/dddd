'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useState } from 'react'
import { AlertCircle, CheckCircle2 } from 'lucide-react'

export default function InitPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const handleCreateAdmin = async () => {
    setIsLoading(true)
    setMessage(null)
    setError(null)
    setSuccess(false)

    try {
      const response = await fetch('/api/init/create-first-admin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: 'c.chalo@gmail.com',
          password: 'vault',
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || 'Failed to create admin user')
      } else {
        setSuccess(true)
        setMessage(`Admin user created successfully! Email: ${data.email}`)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-svh w-full items-center justify-center bg-background p-6 md:p-10">
      <div className="w-full max-w-sm">
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Initialize Admin Account</CardTitle>
            <CardDescription>
              Create the first super admin user for the LMS
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              <div className="space-y-2 p-3 bg-muted rounded-lg">
                <p className="text-sm font-medium">Default Credentials:</p>
                <p className="text-sm text-muted-foreground">Email: c.chalo@gmail.com</p>
                <p className="text-sm text-muted-foreground">Password: vault</p>
              </div>

              {success && (
                <div className="p-3 bg-green-50 border border-green-200 rounded-lg flex gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-green-800">{message}</p>
                </div>
              )}

              {error && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex gap-2">
                  <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-red-800">{error}</p>
                </div>
              )}

              <Button
                onClick={handleCreateAdmin}
                disabled={isLoading || success}
                className="w-full"
              >
                {isLoading ? 'Creating...' : success ? 'Admin Created' : 'Create Admin User'}
              </Button>

              {success && (
                <p className="text-xs text-muted-foreground text-center">
                  You can now <a href="/auth/login" className="underline hover:text-foreground">log in</a> with your admin credentials
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
