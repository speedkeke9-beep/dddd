-- Script to create admin user and profile after auth user is created
-- This script should be run AFTER creating the auth user in Supabase

-- Note: To create the auth user with email c.chalo@gmail.com and password vault:
-- 1. Go to Supabase dashboard
-- 2. Go to Authentication > Users
-- 3. Click "Create new user"
-- 4. Email: c.chalo@gmail.com
-- 5. Password: vault
-- 6. Confirm password: vault
-- 7. Click "Create user"
-- 8. Copy the User ID (UUID)
-- 9. Replace the UUID below with the actual user ID

-- Then run this SQL with the correct UUID:

-- Get the admin user ID from Supabase Auth
-- This will be the UUID of the user created in Supabase Authentication

-- Create profile for admin user (replace UUID with actual user ID)
INSERT INTO public.profiles (id, email, full_name, role, created_at, updated_at)
VALUES (
  (SELECT id FROM auth.users WHERE email = 'c.chalo@gmail.com' LIMIT 1),
  'c.chalo@gmail.com',
  'Admin User',
  'super_admin',
  NOW(),
  NOW()
)
ON CONFLICT (id) DO UPDATE SET
  email = 'c.chalo@gmail.com',
  full_name = 'Admin User',
  role = 'super_admin',
  updated_at = NOW();

-- Enroll admin user in the intro course
INSERT INTO public.enrollments (student_id, course_id)
SELECT 
  (SELECT id FROM auth.users WHERE email = 'c.chalo@gmail.com' LIMIT 1),
  'a1b2c3d4-e5f6-7890-abcd-ef1234567890'
WHERE NOT EXISTS (
  SELECT 1 FROM public.enrollments 
  WHERE student_id = (SELECT id FROM auth.users WHERE email = 'c.chalo@gmail.com' LIMIT 1)
  AND course_id = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890'
);
