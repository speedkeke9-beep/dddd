import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !supabaseKey) {
  console.error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY')
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseKey)

async function setupAdminUser() {
  try {
    console.log('Creating admin user...')
    
    // Create the auth user
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email: 'c.chalo@gmail.com',
      password: 'vault',
      email_confirm: true,
    })

    if (authError) {
      if (authError.message.includes('already exists')) {
        console.log('User already exists')
        // Get the existing user
        const { data: { users }, error: listError } = await supabase.auth.admin.listUsers()
        if (listError) throw listError
        
        const existingUser = users.find(u => u.email === 'c.chalo@gmail.com')
        if (existingUser) {
          console.log(`Using existing user with ID: ${existingUser.id}`)
          await createProfile(existingUser.id)
          return
        }
      } else {
        throw authError
      }
    } else if (authData?.user) {
      console.log(`Created auth user with ID: ${authData.user.id}`)
      await createProfile(authData.user.id)
    }
  } catch (error) {
    console.error('Error setting up admin user:', error)
    process.exit(1)
  }
}

async function createProfile(userId) {
  try {
    console.log('Creating profile for user...')
    
    const { error: profileError } = await supabase
      .from('profiles')
      .upsert({
        id: userId,
        email: 'c.chalo@gmail.com',
        full_name: 'Admin User',
        role: 'super_admin',
      }, {
        onConflict: 'id'
      })

    if (profileError) throw profileError
    
    console.log('✓ Admin user profile created successfully')
    console.log(`\nYou can now login with:`)
    console.log(`Email: c.chalo@gmail.com`)
    console.log(`Password: vault`)
    
  } catch (error) {
    console.error('Error creating profile:', error)
    process.exit(1)
  }
}

setupAdminUser()
