#!/usr/bin/env python3
"""
Script to create the admin user in Supabase
Email: c.chalo@gmail.com
Password: vault
"""

import os
import sys
from supabase import create_client, Client

# Get Supabase credentials from environment
supabase_url = os.getenv('NEXT_PUBLIC_SUPABASE_URL')
supabase_key = os.getenv('SUPABASE_SERVICE_ROLE_KEY')

if not supabase_url or not supabase_key:
    print("Error: NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY environment variables are required")
    sys.exit(1)

# Initialize Supabase client with service role key (admin access)
supabase: Client = create_client(supabase_url, supabase_key)

# Admin user credentials
admin_email = "c.chalo@gmail.com"
admin_password = "vault"
admin_name = "Admin User"

try:
    print(f"Creating admin user: {admin_email}")
    
    # Create the admin user using the admin API
    response = supabase.auth.admin.create_user(
        email=admin_email,
        password=admin_password,
        email_confirm=True,
        user_metadata={
            "full_name": admin_name,
            "role": "super_admin"
        }
    )
    
    user_id = response.user.id
    print(f"✓ Admin user created successfully!")
    print(f"  User ID: {user_id}")
    print(f"  Email: {admin_email}")
    print(f"  Password: {admin_password}")
    
    # Create profile entry in public.profiles
    profile_response = supabase.table('profiles').insert({
        'id': user_id,
        'email': admin_email,
        'full_name': admin_name,
        'role': 'super_admin'
    }).execute()
    
    print(f"✓ Admin profile created in database")
    print("\nYou can now login with:")
    print(f"  Email: {admin_email}")
    print(f"  Password: {admin_password}")
    
except Exception as e:
    print(f"✗ Error creating admin user: {str(e)}")
    sys.exit(1)
